
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func btnCheck(_ sender: UIButton) {
    
        if (sender.isSelected == true)
        {
            sender.setBackgroundImage(UIImage(named: "check.png"), for: UIControlState.normal)
            sender.isSelected = false
            print("Selected")
        }
        else
        {
            sender.setBackgroundImage(UIImage(named: "uncheck.png"), for: UIControlState.normal)
            sender.isSelected = true
            print("disSelected")
        }
        if sender.tag == 1 {
            
            print("single")
        }
        else if sender.tag == 2 {
            
            print("multile")
        }
        else {
            
            print("double")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

